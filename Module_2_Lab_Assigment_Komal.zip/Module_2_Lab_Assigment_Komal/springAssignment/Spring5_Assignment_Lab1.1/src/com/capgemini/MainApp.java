package com.capgemini;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Employee employee = context.getBean(Employee.class, "employee");
		System.out.println("Employee Details\n----------------------------------------");
		System.out.println("Employee ID : "+employee.getE_Id());
		System.out.println("Employee Name : "+employee.getName());
		System.out.println("Employee Salary : "+employee.getSalary());
		System.out.println("Employee BU : "+employee.getBussinessUnit());
		System.out.println("Employee Age : "+employee.getAge());
	}

}
