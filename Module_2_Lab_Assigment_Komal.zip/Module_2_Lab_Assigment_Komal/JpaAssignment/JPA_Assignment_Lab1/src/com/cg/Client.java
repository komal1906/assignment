package com.cg;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("AuthorDetails");
		EntityManager em = factory.createEntityManager();
		
		em.getTransaction().begin();
		
		Author author = new Author();
		author.setFirstName("manas");
		author.setMiddleName("kumar");
		author.setLastName("srivastava");
		author.setPhoneNumber("9795716325");
		em.persist(author);
		
		System.out.println("Added");

		em.getTransaction().commit();
		em.close();
		factory.close();
	}
}
